import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Row, Col, Card, Spin, message } from "antd";
import MediaFeatures from "./MediaFeatures";
import CommunityImpact from "./CommunityImpact";
import AwardAchievement from "./AwardAchievement";

const ProjectsSection = () => {
  const [stories, setStories] = useState([]);
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch both data in parallel
        const [storiesResponse, testimonialsResponse] = await Promise.all([
          fetch("http://localhost:8000/api/patient-stories"),
          fetch("http://localhost:8000/api/testimonials"),
        ]);

        if (!storiesResponse.ok)
          throw new Error("Failed to fetch patient stories");
        if (!testimonialsResponse.ok)
          throw new Error("Failed to fetch testimonials");

        const [storiesData, testimonialsData] = await Promise.all([
          storiesResponse.json(),
          testimonialsResponse.json(),
        ]);

        // Check if the API responses indicate success
        if (storiesData.success) {
          setStories(storiesData.data || []);
        } else {
          throw new Error(
            storiesData.message || "Error fetching patient stories"
          );
        }

        if (testimonialsData.success) {
          setTestimonials(testimonialsData.data || []);
        } else {
          throw new Error(
            testimonialsData.message || "Error fetching testimonials"
          );
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setError(error.message);
        message.error("Failed to load data. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spin size="large" tip="Loading..." />
      </div>
    );
  }

  if (error) {
    return <div className="text-center p-8 text-red-500">Error: {error}</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="container mx-auto p-8 mt-25"
    >
      {/* Stories Section */}
      <h2 className="text-3xl font-semibold mt-10 text-center text-gray-600">
        Patients Share Their Incredible Recovery Stories
      </h2>
      <p className="text-center py-5 text-xl">Our Patient’s Stories</p>
      {/* <p className="text-xl font-semibold mt-10 text-center text-gray-600">
        Hear from our patients as they share their incredible stories of
        resilience, healing, and transformation. Their experiences inspire hope
        and highlight the impact of our dedicated care.
      </p> */}

      {stories.length > 0 ? (
        <Row gutter={[24, 24]} className="mt-6 font-palanquin">
          {stories.map((story, index) => (
            <Col xs={24} sm={12} md={6} key={story.id || index}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                whileHover={{ scale: 1.05 }}
              >
                <Card
                  bordered={false}
                  className="shadow-lg rounded-lg hover:shadow-xl transition-all duration-300 p-3 h-full"
                  cover={
                    story.image ? (
                      <img
                        src={story.image}
                        alt={story.title}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
                        <span className="text-gray-500">No Image</span>
                      </div>
                    )
                  }
                >
                  <h3 className="font-palanquin font-bold text-gray-700 text-lg">
                    {story.title}
                  </h3>
                  <p className="text-gray-600 font-extralight line-clamp-3">
                    {story.description}
                  </p>
                </Card>
              </motion.div>
            </Col>
          ))}
        </Row>
      ) : (
        <div className="text-center p-8 text-gray-500">
          No patient stories available
        </div>
      )}

      {/* Testimonials Section */}
      {testimonials.length > 0 && (
        <>
          <h2 className="text-xl font-semibold mt-16 text-center text-gray-600">
            What People Say
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.id || index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-6 rounded-lg shadow-md"
              >
                <p className="text-gray-600 italic">"{testimonial.quote}"</p>
                <div className="mt-4 flex items-center">
                  {testimonial.avatar && (
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.author}
                      className="w-10 h-10 rounded-full mr-3"
                    />
                  )}
                  <div>
                    <p className="font-semibold text-gray-700">
                      {testimonial.author}
                    </p>
                    {testimonial.role && (
                      <p className="text-sm text-gray-500">
                        {testimonial.role}
                      </p>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </>
      )}

      <MediaFeatures />
      <CommunityImpact />
      <AwardAchievement />
    </motion.div>
  );
};

export default ProjectsSection;
