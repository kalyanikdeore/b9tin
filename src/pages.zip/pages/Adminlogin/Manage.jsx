import React from "react";

function ManageClients() {
  return <div>ManageClients</div>;
}

export default ManageClients;
