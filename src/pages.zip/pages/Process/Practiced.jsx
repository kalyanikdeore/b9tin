import React, { useState, useEffect } from "react";

const Practiced = () => {
  const [sectionData, setSectionData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "http://localhost:8000/api/practiced-section"
        );
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        setSectionData(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  if (!sectionData) return <div>No data found</div>;

  return (
    <div className="bg-gray-200 text-center py-16 px-4">
      <h2 className="text-2xl md:text-3xl font-bold mb-6">
        {sectionData.title}
      </h2>
      <p className="max-w-3xl mx-auto text-sm md:text-base text-gray-800 mb-10 leading-relaxed">
        {sectionData.description}
      </p>

      <div className="flex justify-center mb-8">
        <img
          src={`/storage/${sectionData.image_path}`}
          alt="Nature Informed Therapy Process"
          className="max-w-full md:max-w-4xl rounded-md shadow-lg"
        />
      </div>
    </div>
  );
};

export default Practiced;
