import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import CallToAction from "../Process/CallToAction";
import ProcessAchievements from "./ProcessAchievements";
import VideoSection from "./VideoSection";
import Assessment from "./Assessments";
import Department from "./Department";
import AboutProcess from "./AboutProcess";
import Practiced from "./Practiced";
// Hero Section
// HeroSection Component (unchanged)
const HeroSection = ({ data }) => {
  if (!data) return null;

  return (
    <div
      className="relative bg-cover bg-center h-130 py-44 flex items-center justify-center"
      style={{
        backgroundImage: `url(${data.background_image})`,
      }}
    >
      <div className="bg-opacity-80 w-full h-full absolute top-0 left-0"></div>
      <div className="relative text-center text-white z-10">
        <h1 className="text-5xl mb-6 font-bold">{data.title}</h1>
        <h3 className="italic mt-1">{data.subtitle}</h3>
      </div>
    </div>
  );
};

// Parent component that fetches data
const PageWithHero = async () => {
  const response = await fetch("http://localhost:8000/api/NatureTherapy");
  const data = await response.json();

  return <HeroSection data={data} />;
};

// Main Process Component
function Process() {
  return (
    <div>
      <HeroSection />
      <AboutProcess />
      <Practiced />
      <Department />
      <CallToAction />
      {/* <ProcessAchievements /> */}
      <Assessment />
      {/* <VideoSection /> */}
    </div>
  );
}

export default Process;
