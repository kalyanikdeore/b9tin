import React from 'react';

const NatureInformedTherapy = () => {
  return (
    <div className=" py-12 px-4 text-center text-[#2c2c2c]">
      <h2 className="text-3xl font-bold mb-6">
        What is Nature Informed Therapy (NIT)?
      </h2>
      <p className="max-w-3xl mx-auto text-lg mb-4">
        <strong>Nature Informed Therapy (NIT)</strong> is an innovative approach that integrates the healing power of nature with evidence-based therapeutic practices. Grounded in Ecopsychology, NIT addresses the mental health impacts of nature disconnection by fostering deeper relationships with the environment, oneself, and others. While most health and healing practitioners have established models of human function, NIT adds a foundational layer by incorporating nature into these approaches, enhancing emotional healing, resilience, and personal growth.
      </p>
      <p className="max-w-3xl mx-auto text-lg mb-8">
        A core goal of NIT is reciprocity—forming a healing relationship with individuals that empowers them to care for and heal the planet, creating a mutually beneficial cycle of well-being for both people and the natural world.
      </p>
      <div className="inline-block bg-gray-800 px-6 py-2 rounded-md">
        <button className="text-white text-sm tracking-wide">
          Nature Informed Biopsychosocial-Spiritual Wellbeing Model
        </button>
      </div>
    </div>
  );
};

export default NatureInformedTherapy;
