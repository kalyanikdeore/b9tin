import React from "react";

function NotFound() {
  return <div className="mt-30 text-4xl">NotFound</div>;
}

export default NotFound;
