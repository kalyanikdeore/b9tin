import React from "react";

function AppointmentDelete() {
  return <div>AppointmentDelete</div>;
}

export default AppointmentDelete;
