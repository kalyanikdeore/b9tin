import { useState, useEffect } from "react";
import {
  Form,
  Input,
  Button,
  Select,
  Card,
  Space,
  Spin,
  message,
  Row,
  Col,
} from "antd";
import axiosInstance from "../../services/api";
import useAuthStore from "../../store/authStore";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const { TextArea } = Input;

const QuestionnaireResponseForm = () => {
  const [form] = Form.useForm();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const { appointmentId } = useParams();

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        setLoading(true);
        const response = await axiosInstance.get("/question/active");
        setQuestions(response.data);
      } catch (error) {
        message.error("Failed to fetch questions");
      } finally {
        setLoading(false);
      }
    };

    fetchQuestions();
  }, []);

  const onFinish = async (values) => {
    try {
      setSubmitting(true);

      // Format responses for API - now properly handles all cases
      const responses = questions.map((question) => {
        const questionId = question.id.toString();
        const isDropdownQuestion = question.dropdown_options?.length > 0;

        return {
          questionId: question.id,
          dropdown_answer: isDropdownQuestion ? values[questionId] || "" : "",
          text_answer: isDropdownQuestion
            ? values[`${questionId}_text`] || ""
            : values[questionId] || "",
          userId: user.id,
          appointment_id: appointmentId ? parseInt(appointmentId) : null,
        };
      });

      // Filter out empty responses if needed (optional)
      const validResponses = responses.filter(
        (response) => response.dropdown_answer || response.text_answer
      );

      // Make API call to your backend endpoint
      await axiosInstance.post(`/responses/appointment/${appointmentId}`, {
        responses: validResponses,
      });

      setShowSuccess(true);
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    } catch (error) {
      message.error(
        error.response?.data?.message || "Failed to submit responses"
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spin size="large" />
      </div>
    );
  }

  if (showSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-12"
      >
        <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          Responses Submitted Successfully!
        </h2>
        <p className="text-gray-600">
          Thank you for completing the questionnaire.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card
        title={<h2 className="text-xl font-semibold">Questionnaire</h2>}
        className="shadow-sm"
      >
        <Form
          form={form}
          layout="vertical"
          onFinish={onFinish}
          initialValues={{}}
        >
          {questions.map((question) => (
            <Row key={question.id} gutter={16}>
              <Col span={question.dropdown_options?.length > 0 ? 12 : 24}>
                <Form.Item
                  name={question.id.toString()}
                  label={question.question_text}
                  rules={[
                    {
                      required: true,
                      message: "This question is required",
                      validator: (_, value) =>
                        question.dropdown_options?.length > 0
                          ? value
                            ? Promise.resolve()
                            : Promise.reject("Please select an option")
                          : value?.trim()
                          ? Promise.resolve()
                          : Promise.reject("Please enter your answer"),
                    },
                  ]}
                  className="mb-6"
                >
                  {question.dropdown_options?.length > 0 ? (
                    <Select
                      placeholder="Select an option"
                      options={question.dropdown_options.map((option) => ({
                        value: option,
                        label: option,
                      }))}
                    />
                  ) : (
                    <TextArea
                      rows={3}
                      placeholder="Type your answer here"
                      showCount
                      maxLength={500}
                    />
                  )}
                </Form.Item>
              </Col>
              {question.dropdown_options?.length > 0 && (
                <Col span={12}>
                  <Form.Item
                    name={`${question.id}_text`}
                    label="Additional Comments"
                    className="mb-6"
                  >
                    <TextArea
                      rows={3}
                      placeholder="Any additional comments (optional)"
                      showCount
                      maxLength={500}
                    />
                  </Form.Item>
                </Col>
              )}
            </Row>
          ))}

          <Form.Item>
            <Space>
              <Button
                type="primary"
                htmlType="submit"
                loading={submitting}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Submit Responses
              </Button>
              <Button onClick={() => navigate(-1)}>Cancel</Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default QuestionnaireResponseForm;
