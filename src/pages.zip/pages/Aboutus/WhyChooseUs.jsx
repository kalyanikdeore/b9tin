import React, { useEffect, useState } from "react";
import { FaUserMd, FaChartLine, FaLeaf, FaCouch } from "react-icons/fa";

export default function WhyChooseUsList() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("http://localhost:8000/api/why-choose-us") // your Laravel API URL here
      .then((response) => {
        if (!response.ok) {
          throw new Error(
            `Network response was not ok: ${response.statusText}`
          );
        }
        return response.json();
      })
      .then((data) => {
        if (data.success) {
          setItems(data.data);
        } else {
          setError("Failed to fetch data");
        }
      })
      .catch((err) => {
        setError(err.message);
      });
  }, []);

  if (error) {
    return <div className="text-red-600 font-semibold">Error: {error}</div>;
  }

  return (
    <div className="p-4 max-w-screen-xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-center">Why Choose Us</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {items.map((item) => (
          <div key={item.id} className="p-4 border rounded shadow  transition">
            <div className={`text-3xl mb-2 ${item.icon_color}`}>
              <i className={`fa ${item.icon}`}></i>
            </div>
            <h3 className="font-semibold text-lg">{item.title}</h3>
            <p className="text-gray-700 text-sm">{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
