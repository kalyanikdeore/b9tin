import React from "react";
import Homepage from "./Homepage";
function Home() {
  return (
    <div>
      <Homepage />
    </div>
  );
}

export default Home;
