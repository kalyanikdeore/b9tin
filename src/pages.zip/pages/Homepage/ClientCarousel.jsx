import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { MdImage } from "react-icons/md";
import axios from "axios";

const LogoGrid = () => {
  const [logos, setLogos] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSponsors = async () => {
      try {
        const response = await axios.get("http://localhost:8000/api/sponsors");
        console.log("API Response:", response.data);

        // Check if response.data is an array or contains a 'logos' array
        if (Array.isArray(response.data)) {
          setLogos(response.data);
        } else if (Array.isArray(response.data.logos)) {
          setLogos(response.data.logos);
        } else {
          throw new Error("Invalid response format");
        }
      } catch (error) {
        console.error("Error fetching sponsors:", error);
        setError("Failed to load sponsor logos.");
      }
    };

    fetchSponsors();
  }, []);

  return (
    <div className="bg-gray-50 py-20">
      <div className="container mx-auto">
        {error ? (
          <p className="text-center text-red-600">{error}</p>
        ) : (
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2 place-items-center">
            {logos.map((logo, index) => (
              <motion.div
                key={index}
                whileHover={{ scale: 1.1, filter: "grayscale(100%)" }}
                transition={{ duration: 0.3 }}
                className="relative flex justify-center items-center"
              >
                <img
                  src={logo.image}
                  alt={logo.name}
                  className="h-16 md:h-20 object-contain filter grayscale brightness-75"
                />
                <MdImage className="absolute text-gray-300 text-4xl hidden" />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default LogoGrid;
