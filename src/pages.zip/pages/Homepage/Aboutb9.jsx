import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const Aboutb9 = () => {
  const [aboutData, setAboutData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAboutData = async () => {
      try {
        const response = await fetch(
          "http://localhost:8000/api/about-nature-therapy"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch data");
        }

        const data = await response.json();
        setAboutData(data);
      } catch (err) {
        setError(err.message || "Server error");
      } finally {
        setLoading(false);
      }
    };

    fetchAboutData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div
          className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4"
          role="alert"
        >
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (!aboutData) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div
          className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4"
          role="alert"
        >
          <p className="font-bold">No Data Available</p>
        </div>
      </div>
    );
  }

  return (
    <section className="bg-white py-12 md:py-16 lg:py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            {aboutData.title || "Nature Informed Therapy"}
          </h2>
          <div className="max-w-3xl mx-auto">
            <p className="text-gray-600 leading-relaxed mb-8">
              {aboutData.description}
            </p>
            {aboutData.button_text && (
              <Link to={aboutData.button_link || "/process"}>
                <button className="bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-6 rounded-lg transition duration-300 ease-in-out transform hover:scale-105">
                  {aboutData.button_text} →
                </button>
              </Link>
            )}
          </div>
        </div>

        {aboutData.video_path && (
          <div className="max-w-4xl mx-auto rounded-xl overflow-hidden shadow-lg">
            <video controls className="w-full">
              <source
                src={`/storage/${aboutData.video_path}`}
                type="video/mp4"
              />
              Your browser does not support the video tag.
            </video>
          </div>
        )}
      </div>
    </section>
  );
};

export default Aboutb9;
