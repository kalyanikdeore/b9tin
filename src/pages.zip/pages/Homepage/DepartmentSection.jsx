import { useState, useEffect } from "react";
import axios from "axios";

export default function DepartmentSection() {
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchDepartments = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch("http://localhost:8000/api/departments");

      // Handle both possible response structures
      const data = response.data.data || response.data;

      if (!Array.isArray(data)) {
        throw new Error("Invalid data format received from server");
      }

      setDepartments(data);
      if (data.length > 0) {
        setSelectedDept(data[0]);
      }
    } catch (err) {
      console.error("Error fetching departments:", err);
      setError(
        err.response?.data?.message ||
          err.message ||
          "Failed to load departments. Please try again later."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  if (loading) {
    return (
      <div className="text-center py-15 bg-gray-100">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
        <p className="mt-4">Loading departments...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-15 bg-gray-100">
        <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow">
          <h3 className="text-xl font-semibold text-red-600 mb-2">
            Error Loading Departments
          </h3>
          <p className="mb-4">{error}</p>
          <button
            onClick={fetchDepartments}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  if (departments.length === 0) {
    return (
      <div className="text-center py-15 bg-gray-100">
        <p className="text-lg">No departments available at the moment.</p>
      </div>
    );
  }

  return (
    <div className="text-center py-15 bg-gray-100">
      <h1 className="text-gray-900 text-4xl mb-2">We Are The</h1>
      <h1 className="text-4xl font-semibold mb-20 text-black">
        Best Our Departments Centers
      </h1>

      <div className="flex max-w-6xl mx-auto align-center justify-center gap-4 my-4 flex-wrap">
        {departments.map((dept) => (
          <div
            key={dept.id}
            className={`py-3 px-6 cursor-pointer hover:scale-105 bg-white rounded-3xl flex items-center transition-all ${
              selectedDept?.id === dept.id ? "border-b-4 border-gray-500" : ""
            }`}
            onClick={() => setSelectedDept(dept)}
          >
            {dept.icon && (
              <img
                src={`/storage/${dept.icon}`}
                className="w-12 h-12 object-contain"
                alt={dept.title}
                onError={(e) => {
                  e.target.style.display = "none";
                }}
              />
            )}
            <span className="ml-2 font-medium">{dept.title}</span>
          </div>
        ))}
      </div>

      {selectedDept && (
        <div className="bg-white shadow-lg p-6 max-w-6xl mx-auto flex flex-col md:flex-row items-center my-8 rounded-lg">
          <div className="md:w-1/2 text-left p-4">
            <h1 className="text-2xl font-semibold mb-4">
              {selectedDept.title}
            </h1>
            <p className="text-gray-700">{selectedDept.content}</p>
          </div>
          <div className="md:w-1/2 mt-4 md:mt-0">
            {selectedDept.image && (
              <img
                src={`/storage/${selectedDept.image}`}
                className="w-full h-auto max-h-96 object-cover rounded-lg"
                alt={selectedDept.title}
                onError={(e) => {
                  e.target.style.display = "none";
                }}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
