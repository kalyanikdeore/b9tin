import React, { useState, useEffect } from "react";

import { motion } from "framer-motion";
import { FaAngleDown, FaAngleUp } from "react-icons/fa";

const Accordion = () => {
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8000/api/faqs")
      .then((response) => {
        if (!response.ok) throw new Error("Network response was not ok");
        return response.json();
      })
      .then((data) => {
        console.log("Received FAQ data:", data); // Add logging
        // Adjust based on your API response structure:
        setFaqData(data.faqs || data); // Use whichever matches your API
      })
      .catch((error) => {
        console.error("Error fetching FAQs:", error);
      });
  }, []);

  return (
    <section className="py-1 bg-gray-200">
      <div className="space-y-4">
        {faqData?.map((faq, index) => (
          <Accordion key={index} faq={faq} />
        ))}
      </div>
    </section>
  );
};

export default Accordion;
